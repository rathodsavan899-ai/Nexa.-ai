package com.nexa.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * IMPORTANT (debugging build): onCreate is wrapped in try/catch and this
 * activity installs a global uncaught-exception handler that shows the
 * error ON SCREEN instead of just crashing silently ("keeps stopping" with
 * no visible reason). Once the app is stable, this scaffolding can be
 * removed — its only job right now is to surface *why* it crashes so we
 * don't have to guess without a logcat.
 */
class MainActivity : AppCompatActivity() {

    private var tts: NexaTts? = null
    private var backend: NexaBackendClient? = null
    private var receiverRegistered = false

    private val messageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val sender = intent.getStringExtra(NexaNotificationListenerService.EXTRA_SENDER) ?: return
            val text = intent.getStringExtra(NexaNotificationListenerService.EXTRA_TEXT) ?: return
            Thread {
                try {
                    val toSpeak = if (text.length > 160) backend?.summarize(sender, text) ?: text else text
                    tts?.speak("Message from $sender: $toSpeak")
                } catch (_: Exception) {
                    // Swallow background errors; they must never crash the app.
                }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Catch anything that would otherwise crash the whole app and show
        // it on screen instead, so the real cause is visible without adb.
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                runOnUiThread { showError("Uncaught: ${throwable.javaClass.simpleName}: ${throwable.message}\n\n${throwable.stackTraceToString()}") }
            } catch (_: Exception) {
                // If even the handler fails, fall back to default behavior.
            }
            Thread.sleep(3000) // give the UI a moment to draw before any default crash-dialog takes over
            previousHandler?.uncaughtException(thread, throwable)
        }

        try {
            buildUi()
        } catch (t: Throwable) {
            showError("Crash in onCreate: ${t.javaClass.simpleName}: ${t.message}\n\n${t.stackTraceToString()}")
        }
    }

    private fun buildUi() {
        tts = NexaTts(this)
        backend = NexaBackendClient(baseUrl = "http://10.0.2.2:8000") // point at your backend host

        try {
            ContextCompat.registerReceiver(
                this, messageReceiver,
                IntentFilter(NexaNotificationListenerService.ACTION_MESSAGE_RECEIVED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        } catch (t: Throwable) {
            // Don't let a receiver-registration failure take the whole app down;
            // just note it, since the buttons below still matter on their own.
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        layout.addView(Button(this).apply {
            text = "Enable Accessibility Service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        layout.addView(Button(this).apply {
            text = "Enable Notification Access (message reading)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })

        setContentView(layout)
    }

    private fun showError(message: String) {
        val scroll = ScrollView(this)
        val text = TextView(this).apply {
            text = message
            setTextColor(Color.RED)
            setPadding(32, 96, 32, 32)
            textSize = 12f
        }
        scroll.addView(text)
        setContentView(scroll)
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(messageReceiver) } catch (_: Exception) {}
        }
        tts?.shutdown()
        super.onDestroy()
    }
}
