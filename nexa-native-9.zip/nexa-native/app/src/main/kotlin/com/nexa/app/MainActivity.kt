package com.nexa.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Home screen: shows each permission's live status (green dot = on, red = off)
 * instead of just two plain buttons, so the user isn't guessing whether setup
 * worked. Still wrapped in the same crash-visible safety net as before — if
 * something throws, the error prints on screen instead of "keeps stopping".
 */
class MainActivity : AppCompatActivity() {

    private var tts: NexaTts? = null
    private var backend: NexaBackendClient? = null
    private var receiverRegistered = false

    private lateinit var accessibilityStatusDot: TextView
    private lateinit var accessibilityStatusText: TextView
    private lateinit var accessibilityButton: Button
    private lateinit var notificationStatusDot: TextView
    private lateinit var notificationStatusText: TextView
    private lateinit var notificationButton: Button

    private val messageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val sender = intent.getStringExtra(NexaNotificationListenerService.EXTRA_SENDER) ?: return
            val text = intent.getStringExtra(NexaNotificationListenerService.EXTRA_TEXT) ?: return
            Thread {
                try {
                    val toSpeak = if (text.length > 160) backend?.summarize(sender, text) ?: text else text
                    tts?.speak("Message from $sender: $toSpeak")
                } catch (_: Exception) {
                    // Background errors must never crash the app.
                }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                runOnUiThread { showError("Uncaught: ${throwable.javaClass.simpleName}: ${throwable.message}\n\n${throwable.stackTraceToString()}") }
            } catch (_: Exception) {}
            Thread.sleep(3000)
            previousHandler?.uncaughtException(thread, throwable)
        }

        try {
            buildUi()
        } catch (t: Throwable) {
            showError("Crash in onCreate: ${t.javaClass.simpleName}: ${t.message}\n\n${t.stackTraceToString()}")
        }
    }

    override fun onResume() {
        super.onResume()
        // Coming back from Settings should immediately reflect the new state.
        if (::accessibilityStatusDot.isInitialized) refreshStatus()
    }

    private fun buildUi() {
        tts = NexaTts(this)
        backend = NexaBackendClient(baseUrl = "http://10.0.2.2:8000") // point at your backend host

        try {
            ContextCompat.registerReceiver(
                this, messageReceiver,
                IntentFilter(NexaNotificationListenerService.ACTION_MESSAGE_RECEIVED),
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        } catch (_: Throwable) {}

        val bg = Color.parseColor("#1A1A2E")
        val accent = Color.parseColor("#4FD1C5")
        val textColor = Color.parseColor("#F0F0F5")
        val dimColor = Color.parseColor("#A0A0B0")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "Nexa"
            setTextColor(accent)
            textSize = 32f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Personal AI Agent — setup"
            setTextColor(dimColor)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 48)
        })

        // --- Accessibility row ---
        val accessRow = buildPermissionRow(
            title = "Device control",
            description = "Lets Nexa control flashlight, calls and contacts",
            textColor = textColor,
            dimColor = dimColor
        )
        accessibilityStatusDot = accessRow.second.first
        accessibilityStatusText = accessRow.second.second
        accessibilityButton = Button(this).apply {
            text = "Enable"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        accessRow.first.addView(accessibilityButton)
        root.addView(accessRow.first)

        root.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 24) })

        // --- Notification row ---
        val notifRow = buildPermissionRow(
            title = "Message reading",
            description = "Lets Nexa read and speak WhatsApp / SMS / Gmail alerts",
            textColor = textColor,
            dimColor = dimColor
        )
        notificationStatusDot = notifRow.second.first
        notificationStatusText = notifRow.second.second
        notificationButton = Button(this).apply {
            text = "Enable"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        notifRow.first.addView(notificationButton)
        root.addView(notifRow.first)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        refreshStatus()
    }

    /** Returns the row container, plus (dot, statusText) so the caller can update them later. */
    private fun buildPermissionRow(
        title: String,
        description: String,
        textColor: Int,
        dimColor: Int
    ): Pair<LinearLayout, Pair<TextView, TextView>> {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#24243E"))
            setPadding(32, 32, 32, 32)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 0 }
        }

        val headerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dot = TextView(this).apply {
            text = "●" // ●
            setTextColor(Color.parseColor("#FC8181")) // red until proven otherwise
            textSize = 16f
            setPadding(0, 0, 16, 0)
        }
        val titleView = TextView(this).apply {
            text = title
            setTextColor(textColor)
            textSize = 17f
        }
        headerRow.addView(dot)
        headerRow.addView(titleView)
        card.addView(headerRow)

        card.addView(TextView(this).apply {
            text = description
            setTextColor(dimColor)
            textSize = 13f
            setPadding(0, 8, 0, 16)
        })

        val statusText = TextView(this).apply {
            text = "Checking..."
            setTextColor(dimColor)
            textSize = 13f
            setPadding(0, 0, 0, 16)
        }
        card.addView(statusText)

        return Pair(card, Pair(dot, statusText))
    }

    private fun refreshStatus() {
        val accessibilityOn = isAccessibilityServiceEnabled()
        accessibilityStatusDot.setTextColor(if (accessibilityOn) Color.parseColor("#68D391") else Color.parseColor("#FC8181"))
        accessibilityStatusText.text = if (accessibilityOn) "Enabled" else "Not enabled — tap below"
        accessibilityButton.visibility = if (accessibilityOn) View.GONE else View.VISIBLE

        val notificationOn = isNotificationListenerEnabled()
        notificationStatusDot.setTextColor(if (notificationOn) Color.parseColor("#68D391") else Color.parseColor("#FC8181"))
        notificationStatusText.text = if (notificationOn) "Enabled" else "Not enabled — tap below"
        notificationButton.visibility = if (notificationOn) View.GONE else View.VISIBLE
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${NexaAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabledServices.split(":").any { it.equals(expected, ignoreCase = true) }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        val expected = "$packageName/${NexaNotificationListenerService::class.java.canonicalName}"
        return flat.split(":").any { it.equals(expected, ignoreCase = true) }
    }

    private fun showError(message: String) {
        val scroll = ScrollView(this)
        val text = TextView(this).apply {
            text = message
            setTextColor(Color.RED)
            setPadding(32, 96, 32, 32)
            textSize = 12f
        }
        scroll.addView(text)
        setContentView(scroll)
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(messageReceiver) } catch (_: Exception) {}
        }
        tts?.shutdown()
        super.onDestroy()
    }
}
